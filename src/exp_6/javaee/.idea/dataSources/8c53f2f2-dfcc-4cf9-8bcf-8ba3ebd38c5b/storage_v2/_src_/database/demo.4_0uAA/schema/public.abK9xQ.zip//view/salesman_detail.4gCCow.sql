create view salesman_detail(sname, salary) as
SELECT salesmen.sname,
       salesmen.salary
FROM salesmen;

alter table salesman_detail
    owner to postgres;

