create procedure add_numbers(IN num1 integer, IN num2 integer, OUT result integer)
    language plpgsql
as
$$
BEGIN
    result := num1 + num2;
    RETURN;
END;
$$;

alter procedure add_numbers(integer, integer, out integer) owner to postgres;

