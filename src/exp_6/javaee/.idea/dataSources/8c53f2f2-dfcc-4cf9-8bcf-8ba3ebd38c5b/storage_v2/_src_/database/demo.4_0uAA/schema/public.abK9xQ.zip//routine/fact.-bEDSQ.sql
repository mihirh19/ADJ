create function fact(number integer) returns integer
    language plpgsql
as
$$declare
        result integer := 1;
        i integer;

    begin
        for i in 1..number loop
            result := result * i;
            end loop;

        return result;

end;
$$;

alter function fact(integer) owner to postgres;

