create function calculate_income_tax() returns void
    language plpgsql
as
$$
    DECLARE
        emp_id INTEGER;
        emp_name VARCHAR(50);
        emp_salary numeric(10,2);
        emp_incometax numeric(10,2);

        cur_emp cursor for select eid,ename, salary from emp;

    BEGIN
        open cur_emp;

        fetch cur_emp into emp_id,emp_name, emp_salary;

        while FOUND loop
                emp_incometax := emp_salary *0.2;

            update emp set incometax = emp_incometax where eid = emp_id;

            fetch cur_emp into emp_id,emp_name,emp_salary;
            end loop;
        close cur_emp;
end
$$;

alter function calculate_income_tax() owner to postgres;

