create function update_balance() returns trigger
    language plpgsql
as
$$
DECLARE
    overdraft_amount NUMERIC(10, 2) := 500.00; -- maximum allowed overdraft amount
BEGIN
    -- check if the new balance is less than 0
    IF NEW.balance < 0 THEN
        -- calculate the amount by which the account is overdrawn
        -- and check if it exceeds the maximum allowed overdraft amount
        IF (NEW.balance * -1) > overdraft_amount THEN
            -- if the overdraft amount is exceeded, rollback the transaction
            RAISE EXCEPTION 'Overdraft facility limit exceeded!';
        END IF;
    END IF;

    -- if the balance is not negative or the overdraft amount is not exceeded, update the balance
    RETURN NEW;
END;
$$;

alter function update_balance() owner to postgres;

